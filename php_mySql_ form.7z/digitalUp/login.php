

<!-- login -- after -- mistakeLogin -->

<!DOCTYPE HTML>
<html>

<head>
    
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="icon" href="favicon.ico">
    
</head>

<body>
    
    <ul>
        <li><a href="#">Αρχική</a></li>
        <li><a href="#">Υπηρεσίες</a></li>
        <li><a href="#">Προφίλ</a></li>
        <li><a href="#">Προιόντα</a></li>
        <li><a href="#">Επικοινωνία</a></li>
    </ul>
    <hr>
    <br>

    <p class="bigtext">Need to send images, audio files,and/or videos over text message to send a better message to your potential or current customers? Our service allows you to complete any of these actions using our highly functional API and web service Twitter Art</p>
    <p class="head">LOG IN</p>
    <form action="after.php" method="POST" >
        <input type="text" name="name" placeholder="Username">
        <br>
        
        <br><br>
        <input type="password" name="password" placeholder="Password">
        <br>
        
        <br><br>       
        <input type="submit" name="submit" value="Login" style="background-color:green">
    </form>

    <br>
    <a href="create.php">Νέος λογαριασμός</a>
    

</body>

</html>