<?php

    $con = mysqli_connect('localhost','root','','dbdigital');

    if(!$con)
    {
        echo 'Please Check your Database';
    }

?>    